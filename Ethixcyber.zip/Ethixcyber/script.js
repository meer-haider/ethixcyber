let navLinks = document.getElementById("navLinks");

function showMenu() {
    navLinks.style.top = '0';
}

function hideMenu() {
    navLinks.style.top = '-800px'
}

function shareWebsite() {
    if (navigator.share) {
        navigator.share({
            title: 'Explore ETHIX-CYBER: Your go-to for cybersecurity.',
            text: '🛡️ Explore ETHIX-CYBER: Your go-to for cybersecurity.\n💻 Learn Termux, Kali Linux, Parrot OS, and more.\n📚 Dive into coding and cybersecurity education.\n🌐 Join our community and stay ahead in digital defense.\n🔓 Unlock the secrets of cybersecurity.',
            url: 'https://ethixcyber.in'
        }).then(() => {
            console.log('Thanks for sharing!');
        }).catch(err => {
            console.log("Error while using Web share API:");
            console.log(err);
        });
    } else {
        // Fallback: Copy introduction + link to clipboard
        const introduction = '🛡️ Explore ETHIX-CYBER: Your go-to for cybersecurity.\n💻 Learn Termux, Kali Linux, Parrot OS, and more.\n📚 Dive into coding and cybersecurity education.\n🌐 Join our community and stay ahead in digital defense.\n🔓 Unlock the secrets of cybersecurity.\n';
        const url = 'https://ethixcyber.in';
        const copyText = document.createElement('textarea');
        copyText.value = introduction + url;
        document.body.appendChild(copyText);
        copyText.select();
        document.execCommand('copy');
        document.body.removeChild(copyText);
        
        // Show popup message
        alert("Introduction and link copied to clipboard! Visit ETHIX-CYBER for cybersecurity solutions.");
    }
}

// Attach an event listener to a button or any other element to trigger the function
document.getElementById('shareButton').addEventListener('click', shareWebsite);

function searchContent() {
    var searchInput = document.getElementById("searchInput").value;

    // Create an array of objects representing articles
    var articles = Array.from(document.querySelectorAll("article h2")).map(function (article) {
        return {
            element: article.parentElement,
            text: article.innerText
        };
    });

    // Create a new Fuse instance with your articles' text data
    var fuse = new Fuse(articles, {
        shouldSort: true,
        threshold: 0.3, // Adjust the threshold as needed
        ignoreCase: true,
        keys: ['text']
    });

    // Perform fuzzy search
    var result = fuse.search(searchInput);

    // Show only the matched articles
    articles.forEach(function (article) {
        if (result.includes(article)) {
            article.element.style.display = "inline-block";
        } else {
            article.element.style.display = "none";
        }
    });

    // Display "Not available" warning only if no results
    document.getElementById("notAvailableMessage").style.display = result.length > 0 ? "none" : "block";

    // If no results, refresh the page after a short delay (e.g., 2 seconds)
    if (result.length === 0) {
        setTimeout(function () {
            location.reload();
        }, 2000);
    }
}

function clearSearch() {
    var articles = document.querySelectorAll("article");
    articles.forEach(function (article) {
        article.style.display = "inline-block";
    });

    // Hide "Not available" warning on clear
    document.getElementById("notAvailableMessage").style.display = "none";

    document.getElementById("searchInput").value = "";
}
function sharePage() {
    const pageUrl = window.location.href;
    let shareText = '';

    // Get all h2 elements at the top of the page
    const h2Elements = document.querySelectorAll('h2');
    h2Elements.forEach(h2 => {
        shareText += `${h2.textContent}\n`;
    });

    // Add "Explore more:" and the page URL
    shareText += `Explore more:\n${pageUrl}`;

    if (navigator.share) {
        navigator.share({
            text: shareText,
            url: pageUrl
        }).then(() => {
            console.log('Thanks for sharing!');
        }).catch(err => {
            console.log("Error while using Web share API:");
            console.log(err);
        });
    } else {
        // Fallback: Copy article title + link to clipboard
        const copyText = document.createElement('textarea');
        copyText.value = shareText;
        document.body.appendChild(copyText);
        copyText.select();
        document.execCommand('copy');
        document.body.removeChild(copyText);
        
        // Show popup message
        alert("Link copied to clipboard! Visit the page for more information.");
    }
}


function showPopup() {
    var popupFm = document.getElementById('popupFm');
    popupFm.classList.toggle('show');
    
    // Check if the popup is being hidden
    var isHidden = !popupFm.classList.contains('show');
    
    // If the popup is being hidden, call the reloadPage function
    if (isHidden) {
        reloadPage();
    }
}

function reloadPage() {
    // Reload the current page
    location.reload();
}


function submitForm() {
    var email = document.getElementById("email").value;
    var message = document.getElementById("message").value;

    // Validate email
    if (!validateEmail(email)) {
        var emailError = document.getElementById("email-error");
        emailError.textContent = "Please enter a valid email address.";
        return;
    }

    // Validate message
    if (message.trim() === '') {
        var messageError = document.getElementById("message-error");
        messageError.textContent = "Please enter a message.";
        return;
    }

    // Prepare form data
    var formData = new FormData();
    formData.append("entry.895836713", email); // Replace 1234567890 with the appropriate entry ID for email
    formData.append("entry.1140642762", message); // Replace 0987654321 with the appropriate entry ID for message

    // Submit form data to Google Forms endpoint
    fetch("https://docs.google.com/forms/u/0/d/e/1FAIpQLSeKCZLeYvGuvA71cwPDSejj0dDU0Fh9eIjyO5oz3oaDPWMNiQ/formResponse", {
        method: "POST",
        body: formData
    })
    .then(response => {
        if (response.ok) {
            console.log("Form submitted successfully");
        } else {
            console.error("Error submitting form:", response.statusText);
            // Optionally, display an error message to the user
        }
        // Show popup message
        showMessage();
    })
    .catch(error => {
        console.error("Error submitting form:", error);
        // Handle any errors that occurred during the fetch
        // Show popup message
        showMessage();
    });
}

// Function to validate email address
function validateEmail(email) {
    // Regular expression for validating email address
    var re = /\S+@\S+\.\S+/;
    return re.test(email);
}

// Function to show popup message
function showMessage() {
    // Create a div element for the popup message
    var popup = document.createElement("div");
    popup.className = "popup";
    popup.textContent = "Your message has been successfully submitted. Thank you for reaching out to us! We appreciate your interest and will get back to you as soon as possible.";

    // Apply CSS styles to the popup message
    popup.style.position = "fixed";
    popup.style.bottom = "20px";
    popup.style.left = "50%";
    popup.style.transform = "translateX(-50%)";
    popup.style.backgroundColor = "#4CAF50";
    popup.style.color = "white";
    popup.style.padding = "10px 20px";
    popup.style.borderRadius = "5px";
    popup.style.boxShadow = "0 2px 5px rgba(0, 0, 0, 0.2)";
    popup.style.zIndex = "9999";

    // Add the popup to the document body
    document.body.appendChild(popup);

    // Remove the popup after 5 seconds
    setTimeout(function() {
        popup.parentNode.removeChild(popup);
    }, 5000);
}

function submitvForm() {
    var email = document.getElementById("email").value;
    var message = document.getElementById("message").value;

    // Validate email
    if (!validateEmail(email)) {
        var emailError = document.getElementById("email-error");
        emailError.textContent = "Please enter a valid email address.";
        return;
    }
    // Validate message
    if (message.trim() === '') {
        var messageError = document.getElementById("message-error");
        messageError.textContent = "Please enter a course name.";
        return;
    }

    // Prepare form data
    var formData = new FormData();
    formData.append("entry.1133757741", email); // Replace 1234567890 with the appropriate entry ID for email
    formData.append("entry.143065118", message); // Replace 0987654321 with the appropriate entry ID for message

    // Submit form data to Google Forms endpoint
    fetch("https://docs.google.com/forms/u/0/d/e/1FAIpQLSdGxNexLcZvQoSfCUsDYUreH79XrM_4sUCjBcSa4ETKTDMLHA/formResponse", {
        method: "POST",
        body: formData
    })
    .then(response => {
        if (response.ok) {
            console.log("Form submitted successfully");
        } else {
            console.error("Error submitting form:", response.statusText);
            // Optionally, display an error message to the user
        }
        // Show popup message
        showessage();
    })
    .catch(error => {
        console.error("Error submitting form:", error);
        // Handle any errors that occurred during the fetch
        // Show popup message
        showessage();
    });
}

// Function to show popup message
function showessage() {
    // Create a div element for the popup message
    var popup = document.createElement("div");
    popup.className = "popup";
    popup.textContent = "Thank you for reaching out to us! We appreciate your interest and will get back to you as soon as possible.";

    // Apply CSS styles to the popup message
    popup.style.position = "fixed";
    popup.style.bottom = "20px";
    popup.style.left = "50%";
    popup.style.transform = "translateX(-50%)";
    popup.style.backgroundColor = "#4CAF50";
    popup.style.color = "white";
    popup.style.padding = "10px 20px";
    popup.style.borderRadius = "5px";
    popup.style.boxShadow = "0 2px 5px rgba(0, 0, 0, 0.2)";
    popup.style.zIndex = "9999";

    // Add the popup to the document body
    document.body.appendChild(popup);

    // Remove the popup after 3 seconds
    setTimeout(function() {
        popup.parentNode.removeChild(popup);
    }, 5000);
}

function submitbForm() {
    var email = document.getElementById("email").value;
    var message = document.getElementById("message").value;

    // Validate email
    if (!validateEmail(email)) {
        var emailError = document.getElementById("email-error");
        emailError.textContent = "Please enter a valid email address.";
        return;
    }
 // Validate message
 if (message.trim() === '') {
    var messageError = document.getElementById("message-error");
    messageError.textContent = "Please enter a app link.";
    return;
}
    // Prepare form data
    var formData = new FormData();
    formData.append("entry.1550478741", email); // Replace 1234567890 with the appropriate entry ID for email
    formData.append("entry.2045359280", message); // Replace 0987654321 with the appropriate entry ID for message

    // Submit form data to Google Forms endpoint
    fetch("https://docs.google.com/forms/u/0/d/e/1FAIpQLSf6idHkQMloSWrRB8uyEsRjLJQldy_8DfSWW1PMeVgxqzV5sg/formResponse", {
        method: "POST",
        body: formData
    })
    .then(response => {
        if (response.ok) {
            console.log("Form submitted successfully");
        } else {
            console.error("Error submitting form:", response.statusText);
            // Optionally, display an error message to the user
        }
        // Show popup message
        showessage();
    })
    .catch(error => {
        console.error("Error submitting form:", error);
        // Handle any errors that occurred during the fetch
        // Show popup message
        showessage();
    });
}

// Function to show popup message
function showessage() {
    // Create a div element for the popup message
    var popup = document.createElement("div");
    popup.className = "popup";
    popup.textContent = "Thank you for reaching out to us! We appreciate your interest and will get back to you as soon as possible.";

    // Apply CSS styles to the popup message
    popup.style.position = "fixed";
    popup.style.bottom = "20px";
    popup.style.left = "50%";
    popup.style.transform = "translateX(-50%)";
    popup.style.backgroundColor = "#4CAF50";
    popup.style.color = "white";
    popup.style.padding = "10px 20px";
    popup.style.borderRadius = "5px";
    popup.style.boxShadow = "0 2px 5px rgba(0, 0, 0, 0.2)";
    popup.style.zIndex = "9999";

    // Add the popup to the document body
    document.body.appendChild(popup);

    // Remove the popup after 3 seconds
    setTimeout(function() {
        popup.parentNode.removeChild(popup);
    }, 5000);
}
